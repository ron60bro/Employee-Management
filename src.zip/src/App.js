import React from "react";
import Router from "./routes.js";

function App(){
  return(
    <>
      <Router/>
    </>

  );
}

export default App