import React from 'react';
import employee from './employee123.png';

const Employee=()=>{
    return(
    <>
    <img src={employee} alt=""/>
    
    </>
    );
}
export default Employee;