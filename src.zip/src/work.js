import React from 'react';
import employees from './employee2.jpg';

const Work=()=>{
    return(
    <>
    <img src={employees} alt=""/>
    
    </>
    );
}
export default Work;